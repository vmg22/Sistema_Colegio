const API = "http://localhost:3000/api/v1";

export default API;