import React from 'react'

const LineaSeparadora = () => {
  return (
    <div>
        <hr className="linea-separadora" />
    </div>
  )
}

export default LineaSeparadora