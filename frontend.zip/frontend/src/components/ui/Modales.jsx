import React from 'react'

const Modales = () => {
  return (
    <div>
      
    </div>
  )
}

export default Modales
