import React from 'react'

const Tablas = () => {
  return (
    <div>
      
    </div>
  )
}

export default Tablas
