import React from 'react'
import Navv from '../layout/Navv'
const Header = () => {
  return (
    <div>
      <Navv />
    </div>
  )
}

export default Header
