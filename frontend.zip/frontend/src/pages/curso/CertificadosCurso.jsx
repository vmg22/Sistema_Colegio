import React from 'react'

const certificadosCurso = () => {
  return (
    <div>
      
    </div>
  )
}

export default certificadosCurso
