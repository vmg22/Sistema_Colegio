import React from 'react'

const tomaAsistenciaCurso = () => {
  return (
    <div>
      
    </div>
  )
}

export default tomaAsistenciaCurso
