import React from 'react'

const actaVolanteExamen = () => {
  return (
    <div>
      
    </div>
  )
}

export default actaVolanteExamen
