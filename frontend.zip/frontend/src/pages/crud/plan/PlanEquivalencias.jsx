import React from 'react'

const PlanEquivalencias = () => {
  return (
    <div>PlanEquivalencias</div>
  )
}

export default PlanEquivalencias