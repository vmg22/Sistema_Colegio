import React from 'react'

const Materias = () => {
  return (
    <div>M</div>
  )
}

export default Materias