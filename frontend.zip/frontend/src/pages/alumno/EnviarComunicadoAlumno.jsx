import React from 'react'

const enviarComunicadoAlumno = () => {
  return (
    <div>
      
    </div>
  )
}

export default enviarComunicadoAlumno
