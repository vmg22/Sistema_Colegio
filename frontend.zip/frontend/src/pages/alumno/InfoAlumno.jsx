import React from 'react'

const infoAlumno = () => {
  return (
    <div>
      
    </div>
  )
}

export default infoAlumno
