import React from 'react'

const historialAlumno = () => {
  return (
    <div>
      
    </div>
  )
}

export default historialAlumno
