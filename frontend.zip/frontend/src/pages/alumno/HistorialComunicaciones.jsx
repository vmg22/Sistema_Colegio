import React from 'react'

const HistorialComunicaciones = () => {
  return (
    <div>
      historcomu
    </div>
  )
}

export default HistorialComunicaciones
