import React from 'react'

const certificadosAlumno = () => {
  return (
    <div>
      
    </div>
  )
}

export default certificadosAlumno
