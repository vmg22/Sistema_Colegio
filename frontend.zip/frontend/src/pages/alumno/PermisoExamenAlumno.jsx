import React from 'react'

const PermisoExamenAlumno = () => {
  return (
    <div>
      
    </div>
  )
}

export default PermisoExamenAlumno
